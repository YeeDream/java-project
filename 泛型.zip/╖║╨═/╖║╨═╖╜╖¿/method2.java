package 复习.泛型.泛型方法;

/**
 * @Author DreamYee
 * @Create 2020/02/23  15:53
 */
public class method2 {
    public static <T> String By(T bus,T taxi){
        String gongju="aaa";
        if(gongju!=bus){
            return gongju;
        }else {
            return "啊啊啊";
        }
    }

    public static void main(String[] args) {
        String by=By("aaa","bbb");
        System.out.println(by);
    }
}
