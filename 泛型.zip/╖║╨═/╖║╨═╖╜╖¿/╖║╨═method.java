package 复习.泛型.泛型方法;

import java.util.ArrayList;
import java.util.List;

/**
 * @Author DreamYee
 * @Create 2020/02/23  15:49
 */
public class 泛型method {
    public static <T> int find(List<T> lst,T a){
        int index=-1;
        if(lst!=null){
            index=lst.indexOf(a);
        }
        return index;
    }

    public static void main(String[] args) {
        int find=find(new ArrayList<String>(),"A");
        System.out.println(find);
    }
}
