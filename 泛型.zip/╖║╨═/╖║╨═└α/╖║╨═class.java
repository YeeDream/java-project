package 复习.泛型.泛型类;

/**
 * @Author DreamYee
 * @Create 2020/02/23  15:10
 */
public class 泛型class<T> {
    private T apple;
    private T pear;

    public 泛型class(){
        apple=null;
        pear=null;
    }

    public 泛型class(T apple,T pear){
        this.apple=apple;
        this.pear=pear;
    }

    public T getApple(){
      return apple;
    }

    public void setApple(T apple) {
        this.apple = apple;
    }

    public T getPear(){
        return pear;
    }

    public void setPear(T pear) {
        this.pear = pear;
    }

    public static void main(String[] args) {
        泛型class<String> aClass=new 泛型class<>("我是苹果","我是梨");

        System.out.println(aClass.getApple());
        System.out.println(aClass.getPear());


    }
}
