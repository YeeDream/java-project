package 复习.泛型.通配符问题;

import java.util.ArrayList;
import java.util.List;

/**
 * @Author DreamYee
 * @Create 2020/02/23  17:08
 */
public class 通配符 {
    public static void main(String[] args) {
        List<String> lst1=new ArrayList<String>();
        lst1.add("A");
        List<Integer> lst2=new ArrayList<Integer>();
        lst2.add(1);
        printList_T(lst1);
        printList_T(lst2);
        System.out.println("---------------");
        printList(lst1);
        printList(lst2);

    }

    //常规泛型
    private static <T> void printList_T(List<T> list){
        list.add(list.get(0));
        for(int i=0;i<list.size();i++){
            Object o=list.get(i);
            System.out.println(o);
        }
    }

    //通配符
    private static void printList(List<?> list){
        for(int i=0;i<list.size();i++){
            Object o=list.get(i);
            System.out.println(o);
        }
    }
}
