package 复习.泛型.通配符问题;

import java.util.ArrayList;
import java.util.List;

/**
 * @Author DreamYee
 * @Create 2020/02/23  16:57
 */
public class 上限 {
    public static void main(String[] args) {
        ArrayList<Apple> p1=new ArrayList<Apple>();
        ArrayList<? extends Apple> p3=new ArrayList<Apple>();
        p3=new ArrayList<RedApple>();
        if(p3.size()!=0){
            Apple apple=p3.get(0);
        }

        ArrayList<? super Apple> p4=new ArrayList<Apple>();
        p4=new ArrayList<Fruit>();
        p4=new ArrayList<Apple>();

        p4.add(new RedApple());
        Object o=p4.get(0);
        System.out.println(o);
        List<Apple> p2=new ArrayList<>();
    }

}

class Fruit{

}

class Apple extends Fruit{

}

class RedApple extends Apple{

}
